"use strict";(()=>{var e={};e.id=386,e.ids=[386],e.modules={20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},61282:e=>{e.exports=require("child_process")},84770:e=>{e.exports=require("crypto")},80665:e=>{e.exports=require("dns")},17702:e=>{e.exports=require("events")},92048:e=>{e.exports=require("fs")},32615:e=>{e.exports=require("http")},35240:e=>{e.exports=require("https")},98216:e=>{e.exports=require("net")},19801:e=>{e.exports=require("os")},55315:e=>{e.exports=require("path")},76162:e=>{e.exports=require("stream")},82452:e=>{e.exports=require("tls")},17360:e=>{e.exports=require("url")},21764:e=>{e.exports=require("util")},71568:e=>{e.exports=require("zlib")},15466:(e,r,t)=>{t.r(r),t.d(r,{originalPathname:()=>x,patchFetch:()=>v,requestAsyncStorage:()=>g,routeModule:()=>c,serverHooks:()=>u,staticGenerationAsyncStorage:()=>m});var o={};t.r(o),t.d(o,{POST:()=>d});var s=t(49303),a=t(88716),n=t(60670),i=t(87070),p=t(55245);let l=()=>process.env.SMTP_HOST&&process.env.SMTP_USER&&process.env.SMTP_PASS?(console.log("Usando configura\xe7\xe3o SMTP personalizada para contato"),p.createTransport({host:process.env.SMTP_HOST,port:parseInt(process.env.SMTP_PORT||"587"),secure:"true"===process.env.SMTP_SECURE,auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASS},tls:{rejectUnauthorized:!1}})):(console.log("Usando configura\xe7\xe3o Gmail para contato"),p.createTransport({service:"gmail",auth:{user:process.env.EMAIL_USER,pass:process.env.EMAIL_PASS}}));async function d(e){try{let{name:r,email:t,subject:o,message:s}=await e.json();if(!r||!t||!s)return i.NextResponse.json({error:"Nome, email e mensagem s\xe3o obrigat\xf3rios"},{status:400});if(!t.includes("@"))return i.NextResponse.json({error:"Email inv\xe1lido"},{status:400});if(s.length<10)return i.NextResponse.json({error:"A mensagem deve ter pelo menos 10 caracteres"},{status:400});if(s.length>2e3)return i.NextResponse.json({error:"A mensagem deve ter no m\xe1ximo 2000 caracteres"},{status:400});let a=l(),n=process.env.SMTP_USER||process.env.EMAIL_USER,p={from:n,to:n,subject:`Nova mensagem de contato: ${o||"Sem assunto"}`,html:`
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 20px; text-align: center;">
            <h1 style="color: white; margin: 0;">Nova Mensagem de Contato</h1>
          </div>
          
          <div style="padding: 30px; background: #f9f9f9;">
            <h2 style="color: #333; margin-bottom: 20px;">Detalhes do Contato</h2>
            
            <div style="margin-bottom: 20px;">
              <strong style="color: #333;">Nome:</strong>
              <p style="color: #666; margin: 5px 0;">${r}</p>
            </div>
            
            <div style="margin-bottom: 20px;">
              <strong style="color: #333;">Email:</strong>
              <p style="color: #666; margin: 5px 0;">${t}</p>
            </div>
            
            ${o?`
            <div style="margin-bottom: 20px;">
              <strong style="color: #333;">Assunto:</strong>
              <p style="color: #666; margin: 5px 0;">${o}</p>
            </div>
            `:""}
            
            <div style="margin-bottom: 20px;">
              <strong style="color: #333;">Mensagem:</strong>
              <div style="color: #666; margin: 5px 0; line-height: 1.6; white-space: pre-wrap;">${s}</div>
            </div>
            
            <div style="margin-top: 30px; padding: 15px; background: #e8f4fd; border-left: 4px solid #2196f3;">
              <p style="color: #333; margin: 0; font-size: 14px;">
                <strong>Data:</strong> ${new Date().toLocaleString("pt-BR")}<br>
                <strong>IP:</strong> ${e.headers.get("x-forwarded-for")||e.headers.get("x-real-ip")||"N/A"}
              </p>
            </div>
          </div>
          
          <div style="background: #333; padding: 20px; text-align: center;">
            <p style="color: #999; margin: 0; font-size: 12px;">
              \xa9 2024 CORNOS BRASIL. Mensagem enviada via formul\xe1rio de contato.
            </p>
          </div>
        </div>
      `},d={from:n,to:t,subject:"Recebemos sua mensagem - CORNOS BRASIL",html:`
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 20px; text-align: center;">
            <h1 style="color: white; margin: 0;">CORNOS BRASIL</h1>
          </div>
          
          <div style="padding: 30px; background: #f9f9f9;">
            <h2 style="color: #333; margin-bottom: 20px;">Mensagem Recebida!</h2>
            
            <p style="color: #666; line-height: 1.6; margin-bottom: 20px;">
              Ol\xe1 <strong>${r}</strong>,
            </p>
            
            <p style="color: #666; line-height: 1.6; margin-bottom: 20px;">
              Recebemos sua mensagem e agradecemos por entrar em contato conosco. 
              Nossa equipe ir\xe1 analisar sua solicita\xe7\xe3o e responderemos o mais breve poss\xedvel.
            </p>
            
            <div style="background: #e8f5e8; border-left: 4px solid #4caf50; padding: 15px; margin: 20px 0;">
              <h3 style="color: #333; margin: 0 0 10px 0;">Resumo da sua mensagem:</h3>
              <p style="color: #666; margin: 0; font-style: italic;">${s.substring(0,200)}${s.length>200?"...":""}</p>
            </div>
            
            <p style="color: #666; line-height: 1.6; margin-bottom: 20px;">
              <strong>Tempo de resposta esperado:</strong><br>
              • Suporte via Telegram: at\xe9 5 minutos<br>
              • Email: at\xe9 24 horas
            </p>
            
            <div style="text-align: center; margin: 30px 0;">
              <a href="https://t.me/cornosbrasil" 
                 style="background: #0088cc; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; display: inline-block; font-weight: bold;">
                Falar no Telegram
              </a>
            </div>
          </div>
          
          <div style="background: #333; padding: 20px; text-align: center;">
            <p style="color: #999; margin: 0; font-size: 12px;">
              \xa9 2024 CORNOS BRASIL. Esta \xe9 uma confirma\xe7\xe3o autom\xe1tica.
            </p>
          </div>
        </div>
      `};return await a.sendMail(p),await a.sendMail(d),console.log(`Nova mensagem de contato de ${r} (${t}): ${o||"Sem assunto"}`),i.NextResponse.json({message:"Mensagem enviada com sucesso! Entraremos em contato em breve."},{status:200})}catch(e){return console.error("Erro ao processar mensagem de contato:",e),i.NextResponse.json({error:"Erro interno do servidor. Tente novamente."},{status:500})}}let c=new s.AppRouteRouteModule({definition:{kind:a.x.APP_ROUTE,page:"/api/contact/route",pathname:"/api/contact",filename:"route",bundlePath:"app/api/contact/route"},resolvedPagePath:"D:\\Apps\\extras\\app\\api\\contact\\route.ts",nextConfigOutput:"",userland:o}),{requestAsyncStorage:g,staticGenerationAsyncStorage:m,serverHooks:u}=c,x="/api/contact/route";function v(){return(0,n.patchFetch)({serverHooks:u,staticGenerationAsyncStorage:m})}}};var r=require("../../../webpack-runtime.js");r.C(e);var t=e=>r(r.s=e),o=r.X(0,[8948,5972,4043],()=>t(15466));module.exports=o})();
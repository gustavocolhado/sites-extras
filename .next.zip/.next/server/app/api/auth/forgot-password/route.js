"use strict";(()=>{var e={};e.id=9118,e.ids=[9118],e.modules={20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},61282:e=>{e.exports=require("child_process")},84770:e=>{e.exports=require("crypto")},80665:e=>{e.exports=require("dns")},17702:e=>{e.exports=require("events")},92048:e=>{e.exports=require("fs")},32615:e=>{e.exports=require("http")},35240:e=>{e.exports=require("https")},98216:e=>{e.exports=require("net")},19801:e=>{e.exports=require("os")},55315:e=>{e.exports=require("path")},76162:e=>{e.exports=require("stream")},82452:e=>{e.exports=require("tls")},17360:e=>{e.exports=require("url")},21764:e=>{e.exports=require("util")},71568:e=>{e.exports=require("zlib")},90574:(e,r,o)=>{o.r(r),o.d(r,{originalPathname:()=>m,patchFetch:()=>f,requestAsyncStorage:()=>S,routeModule:()=>h,serverHooks:()=>v,staticGenerationAsyncStorage:()=>g});var t={};o.r(t),o.d(t,{POST:()=>x});var s=o(49303),a=o(88716),i=o(60670),n=o(87070),p=o(83493),u=o(84770),c=o.n(u),d=o(55245);let l=process.env.SMTP_HOST&&process.env.SMTP_USER&&process.env.SMTP_PASS?(console.log("Usando configura\xe7\xe3o SMTP personalizada:",{host:process.env.SMTP_HOST,port:process.env.SMTP_PORT,user:process.env.SMTP_USER,secure:process.env.SMTP_SECURE}),d.createTransport({host:process.env.SMTP_HOST,port:parseInt(process.env.SMTP_PORT||"587"),secure:"true"===process.env.SMTP_SECURE,auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASS},tls:{rejectUnauthorized:!1}})):(console.log("Usando configura\xe7\xe3o Gmail padr\xe3o"),d.createTransport({service:"gmail",auth:{user:process.env.EMAIL_USER,pass:process.env.EMAIL_PASS}}));async function x(e){try{let{email:r}=await e.json();if(!r)return n.NextResponse.json({error:"Email \xe9 obrigat\xf3rio"},{status:400});if(!await p._.user.findUnique({where:{email:r}}))return n.NextResponse.json({message:"Se o email existir, voc\xea receber\xe1 um link de recupera\xe7\xe3o"},{status:200});let o=c().randomBytes(32).toString("hex"),t=new Date(Date.now()+36e5);await p._.user.update({where:{email:r},data:{resetToken:o,resetTokenExpiration:t}});let s=`${process.env.NEXTAUTH_URL}/reset-password?token=${o}`,a={from:process.env.SMTP_USER||process.env.EMAIL_USER,to:r,subject:"Recupera\xe7\xe3o de Senha - CORNOS BRASIL",html:`
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 20px; text-align: center;">
            <h1 style="color: white; margin: 0;">CORNOS BRASIL</h1>
          </div>
          
          <div style="padding: 30px; background: #f9f9f9;">
            <h2 style="color: #333; margin-bottom: 20px;">Recupera\xe7\xe3o de Senha</h2>
            
            <p style="color: #666; line-height: 1.6; margin-bottom: 20px;">
              Voc\xea solicitou a recupera\xe7\xe3o de senha para sua conta. Clique no bot\xe3o abaixo para criar uma nova senha:
            </p>
            
            <div style="text-align: center; margin: 30px 0;">
              <a href="${s}" 
                 style="background: #667eea; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; display: inline-block; font-weight: bold;">
                Redefinir Senha
              </a>
            </div>
            
            <p style="color: #666; line-height: 1.6; margin-bottom: 20px;">
              Se voc\xea n\xe3o solicitou esta recupera\xe7\xe3o, ignore este email. O link expira em 1 hora.
            </p>
            
            <p style="color: #999; font-size: 12px; margin-top: 30px;">
              Se o bot\xe3o n\xe3o funcionar, copie e cole este link no seu navegador:<br>
              <a href="${s}" style="color: #667eea;">${s}</a>
            </p>
          </div>
          
          <div style="background: #333; padding: 20px; text-align: center;">
            <p style="color: #999; margin: 0; font-size: 12px;">
              \xa9 2024 CORNOS BRASIL. Todos os direitos reservados.
            </p>
          </div>
        </div>
      `};return await l.sendMail(a),n.NextResponse.json({message:"Se o email existir, voc\xea receber\xe1 um link de recupera\xe7\xe3o"},{status:200})}catch(e){return console.error("Erro ao processar recupera\xe7\xe3o de senha:",e),n.NextResponse.json({error:"Erro interno do servidor"},{status:500})}}let h=new s.AppRouteRouteModule({definition:{kind:a.x.APP_ROUTE,page:"/api/auth/forgot-password/route",pathname:"/api/auth/forgot-password",filename:"route",bundlePath:"app/api/auth/forgot-password/route"},resolvedPagePath:"D:\\Apps\\extras\\app\\api\\auth\\forgot-password\\route.ts",nextConfigOutput:"",userland:t}),{requestAsyncStorage:S,staticGenerationAsyncStorage:g,serverHooks:v}=h,m="/api/auth/forgot-password/route";function f(){return(0,i.patchFetch)({serverHooks:v,staticGenerationAsyncStorage:g})}},83493:(e,r,o)=>{let t;o.d(r,{_:()=>t}),t=new(require("@prisma/client")).PrismaClient}};var r=require("../../../../webpack-runtime.js");r.C(e);var o=e=>r(r.s=e),t=r.X(0,[8948,5972,4043],()=>o(90574));module.exports=t})();
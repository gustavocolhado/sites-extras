import { headers } from 'next/headers'
import { getDomainConfig, type DomainConfig } from '@/config/domains'

export function getServerDomainConfig(): DomainConfig {
  const headersList = headers()
  const hostname = headersList.get('host') || ''
  const domain = hostname.replace(/:\d+$/, '').toLowerCase()
  
  return getDomainConfig(domain)
}

export function getServerDomain(): string {
  const headersList = headers()
  const hostname = headersList.get('host') || ''
  return hostname.replace(/:\d+$/, '').toLowerCase()
}

export function generateMetadata(domainConfig: DomainConfig) {
  return {
    title: domainConfig.title,
    description: domainConfig.description,
    keywords: domainConfig.keywords,
    authors: [{ name: domainConfig.siteName }],
    creator: domainConfig.siteName,
    publisher: domainConfig.siteName,
    metadataBase: new URL(domainConfig.canonical),
    alternates: {
      canonical: '/',
    },
    openGraph: {
      title: domainConfig.title,
      description: domainConfig.description,
      url: domainConfig.canonical,
      siteName: domainConfig.siteName,
      images: [
        {
          url: domainConfig.ogImage,
          width: 1200,
          height: 630,
          alt: domainConfig.title,
        },
      ],
      locale: 'pt_BR',
      type: 'website',
    },
    twitter: {
      card: 'summary_large_image',
      title: domainConfig.title,
      description: domainConfig.description,
      images: [domainConfig.ogImage],
    },
    robots: {
      index: true,
      follow: true,
      googleBot: {
        index: true,
        follow: true,
        'max-video-preview': -1,
        'max-image-preview': 'large' as const,
        'max-snippet': -1,
      },
    },
    verification: {
      google: 'your-google-verification-code',
      yandex: 'your-yandex-verification-code',
      yahoo: 'your-yahoo-verification-code',
    },
  }
}

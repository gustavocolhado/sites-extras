'use client'

import LandingPage from '@/components/LandingPage'

export default function CampaignPage() {
  return <LandingPage />
} 